/*=========================================================================================
  File Name: auth-register.js
  Description: Auth register js file.
  ----------------------------------------------------------------------------------------
  Item Name: Vuexy  - Vuejs, HTML & Laravel Admin Dashboard Template
  Author: PIXINVENT
  Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

$(function () {
  ('use strict');
  var assetsPath = '../../../app-assets/',
    registerMultiStepsWizard = document.querySelector('.register-multi-steps-wizard'),
    pageResetForm = $('.auth-register-form'),
    select = $('.select2'),
    creditCard = $('.credit-card-mask'),
    expiryDateMask = $('.expiry-date-mask'),
    cvvMask = $('.cvv-code-mask'),
    mobileNumberMask = $('.mobile-number-mask'),
    pinCodeMask = $('.pin-code-mask');

  if ($('body').attr('data-framework') === 'laravel') {
    assetsPath = $('body').attr('data-asset-path');
  }
  var baseurl = window.location.origin;

  var url = window.location.href;
  var id = url.substring(url.lastIndexOf('/') + 1);
  if ($.isNumeric(id) == true) {
    $('#submit_button').text('Update');
    $.ajax({
      url: baseurl + '/receptionist/get-receptionist-by-id/',
      type: 'GET',
      data:  {id: id},
      success: function(response) {
        if (response.status == 'success') {
          var userInfo = response.userInfo;
          $('#id').val(userInfo.id);
          $('#firstname').val(userInfo.firstname);
          $('#lastname').val(userInfo.lastname);
          $('#email').val(userInfo.email);
          $('#cnic').val(userInfo.cnic);
          $('#phone').val(userInfo.role_id);
          $('#address').val(userInfo.address);
          $('#is_employee').val(userInfo.is_employee).trigger('change');
          $('#role_id').val(userInfo.role_id).trigger('change');
          $('#status').val(userInfo.status).trigger('change');
          $('#dob').val(userInfo.dob).trigger('change');
          $('input[name=gender][value=' + userInfo.gender + ']').prop('checked', true);
          $('#er_firstname').val(userInfo.er_firstname);
          $('#er_lastname').val(userInfo.er_lastname);
          $('#er_email').val(userInfo.er_email);
          $('#er_phone').val(userInfo.er_phone);
          $('#er_cnic').val(userInfo.er_cnic);
          $('#er_address').val(userInfo.er_address);

          $('#receptionist_id').val(userInfo.receptionist ? userInfo.receptionist.id : '');
          $('#shift').val(userInfo.receptionist ? userInfo.receptionist.shift : '').trigger('change');
          
          $('#employee_id').val(userInfo.employee ? userInfo.employee.id : '');
          $('#designation').val(userInfo.employee ? userInfo.employee.designation : '');
          $('#qualification').val(userInfo.employee ? userInfo.employee.qualification : '');
          $('#joining_date').val(userInfo.employee ? userInfo.employee.joining_date : '');
          $('#last_date').val(userInfo.employee ? userInfo.employee.last_date : '');
        }
      },
      error: function(xhr, status, error) {
        // Handle error response
        console.log('status');
      }
    });
  }
  
  $('form').each(function() {
    this.reset();
  });

  $("#is_employee").on('click', function() {
    if ($(this).is(':checked')) {
        $(this).val('1');
    } else {
        $(this).val('0');
    }
  });

  // jQuery Validation
  // --------------------------------------------------------------------
  if (pageResetForm.length) {
    pageResetForm.validate({
      /*
      * ? To enable validation onkeyup
      onkeyup: function (element) {
        $(element).valid();
      },*/
      /*
      * ? To enable validation on focusout
      onfocusout: function (element) {
        $(element).valid();
      }, */
      rules: {
        'register-username': {
          required: false
        },
        'register-email': {
          required: false,
          email: true
        }
      }
    });
  }

  // multi-steps registration
  // --------------------------------------------------------------------

  // Horizontal Wizard
  if (typeof registerMultiStepsWizard !== undefined && registerMultiStepsWizard !== null) {
    var numberedStepper = new Stepper(registerMultiStepsWizard),
      $form = $(registerMultiStepsWizard).find('form');
    $form.each(function () {
      var $this = $(this);
      $this.validate({
        rules: {
          username: {
            required: false
          },
          email: {
            required: false
          },
          
          'first-name': {
            required: false
          },
          'home-address': {
            required: false
          },
          addCard: {
            required: false
          }
        },
        messages: {
          password: {
            required: 'Enter new password',
            minlength: 'Enter at least 8 characters'
          },
          'confirm-password': {
            required: 'Please confirm new password',
            minlength: 'Enter at least 8 characters',
            equalTo: 'The password and its confirm are not the same'
          }
        }
      });
    });

    $(registerMultiStepsWizard)
      .find('.btn-next')
      .each(function () {
        $(this).on('click', function (e) {
          var isValid = $(this).parent().siblings('form').valid();
          if (isValid) {
            numberedStepper.next();
          } else {
            e.preventDefault();
          }
        });
      });

    $(registerMultiStepsWizard)
      .find('.btn-prev')
      .on('click', function () {
        numberedStepper.previous();
      });

    $(registerMultiStepsWizard)
      .find('.btn-submit')
      .on('click', function () {
        var formData = {};
        var isValid = $(this).parent().siblings('form').valid();

        if (isValid) {          
          inputFields = $(registerMultiStepsWizard).find('form').find('input');
          inputFields.each(function() {
            var input = $(this);
            var fieldName = input.attr('name');
            var fieldValue = input.val();
            formData[fieldName] = fieldValue;
          });

          selectBoxes = $(registerMultiStepsWizard).find('form').find('select');
          selectBoxes.each(function() {
            var select = $(this);
            var fieldName = select.attr('name');
            var fieldValue = select.val();
            formData[fieldName] = fieldValue;
          });

          checkBox = $(registerMultiStepsWizard).find('form').find('checkbox');
          checkBox.each(function() {
            var select = $(this);
            var fieldName = select.attr('name');
            var fieldValue = select.val();
            formData[fieldName] = fieldValue;
          });

          formData['gender'] = $('input[name="gender"]:checked').val();
          if (formData) {
            if (formData['id']) {
              var dataSaveRoute = 'receptionist/update';
              var successMesg = 'receptionist updated successfully.';
            } else {
              var dataSaveRoute = 'receptionist/create';
              var successMesg = 'receptionist created successfully.';
            }
            $.ajax({
              url: assetPath + dataSaveRoute,
              type: 'POST',
              data:  formData,
              success: function(response) {
                if (response.status == 'success') {
                  Swal.fire({
                    title: 'Success',
                    text: successMesg,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
                }
              },
              error: function(xhr, status, error) {
                Swal.fire({
                  title: 'error',
                  text: error,
                  icon: 'error',
                  confirmButtonText: 'OK'
              });
              }
            });
          }
        }
      });
  }

  // select2
  select.each(function () {
    var $this = $(this);
    $this.wrap('<div class="position-relative"></div>');
    $this.select2({
      // the following code is used to disable x-scrollbar when click in select input and
      // take 100% width in responsive also
      dropdownAutoWidth: true,
      width: '100%',
      dropdownParent: $this.parent()
    });
  });

  // credit card

  // Credit Card
  if (creditCard.length) {
    creditCard.each(function () {
      new Cleave($(this), {
        creditCard: true,
        onCreditCardTypeChanged: function (type) {
          const elementNodeList = document.querySelectorAll('.card-type');
          if (type != '' && type != 'unknown') {
            //! we accept this approach for multiple credit card masking
            for (let i = 0; i < elementNodeList.length; i++) {
              elementNodeList[i].innerHTML =
                '<img src="' + assetsPath + 'images/icons/payments/' + type + '-cc.png" height="24"/>';
            }
          } else {
            for (let i = 0; i < elementNodeList.length; i++) {
              elementNodeList[i].innerHTML = '';
            }
          }
        }
      });
    });
  }

  // Expiry Date Mask
  if (expiryDateMask.length) {
    new Cleave(expiryDateMask, {
      date: true,
      delimiter: '/',
      datePattern: ['m', 'y']
    });
  }

  // CVV
  if (cvvMask.length) {
    new Cleave(cvvMask, {
      numeral: true,
      numeralPositiveOnly: true
    });
  }

  // phone number mask
  if (mobileNumberMask.length) {
    new Cleave(mobileNumberMask, {
      phone: true,
      phoneRegionCode: 'US'
    });
  }

  // Pincode
  if (pinCodeMask.length) {
    new Cleave(pinCodeMask, {
      delimiter: '',
      numeral: true
    });
  }
  var assetPath = '../../../app-assets/',
  userView = 'app-user-view-account.html';

  if ($('body').attr('data-framework') === 'laravel') {
    assetPath = $('body').attr('data-asset-path');
    userView = assetPath + 'app/user/view/account';
  }
  
  // multi-steps registration
  // --------------------------------------------------------------------
});
