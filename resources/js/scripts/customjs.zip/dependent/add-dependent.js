/*=========================================================================================
  File Name: auth-register.js
  Description: Auth register js file.
  ----------------------------------------------------------------------------------------
  Item Name: Vuexy  - Vuejs, HTML & Laravel Admin Dashboard Template
  Author: PIXINVENT
  Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

$(function () {
  ('use strict');
  var assetsPath = '../../../app-assets/',
    registerMultiStepsWizard = document.querySelector('.register-multi-steps-wizard'),
    pageResetForm = $('.auth-register-form'),
    select = $('.select2'),
    creditCard = $('.credit-card-mask'),
    expiryDateMask = $('.expiry-date-mask'),
    cvvMask = $('.cvv-code-mask'),
    mobileNumberMask = $('.mobile-number-mask'),
    pinCodeMask = $('.pin-code-mask');

  if ($('body').attr('data-framework') === 'laravel') {
    assetsPath = $('body').attr('data-asset-path');
  }
  var baseurl = window.location.origin;

  var url = window.location.href;
    var id = url.substring(url.lastIndexOf('/') + 1);
    //console.log($.isNumeric(id));return;
    if ($.isNumeric(id) == true) {

      $('#submit_button').text('Update');
      $.ajax({
        url: baseurl + '/dependent/get-dependent-by-id/',
        type: 'GET',
        data:  {id: id},
        success: function(response) {
          if (response.status == 'success') {
            var userInfo = response.userInfo;
            $('#id').val(userInfo.id);
            $('#firstname').val(userInfo.firstname);
            $('#lastname').val(userInfo.lastname);
            $('#email').val(userInfo.email);
            $('#cnic').val(userInfo.cnic);
            $('#phone').val(userInfo.role_id);
            $('#address').val(userInfo.address);
            // if(userInfo.is_dependent == 1) {
            //   $('#is_dependent').val(userInfo.is_dependent);
            // }
            $('#role_id').val(userInfo.role_id).trigger('change');
            $('#patient_id').val(userInfo.patient ? userInfo.patient.id : '');
            $('#patient_type_id').val(userInfo.patient ? userInfo.patient.patient_type_id : '').trigger('change');
            $('#status').val(userInfo.status).trigger('change');
            $('#dependent_id').val(userInfo.dependent ? userInfo.dependent.id : '');
            $('#depends_on_user_id').val(userInfo.dependent ? userInfo.dependent.depends_on_user_id : '').trigger('change');

            console.log(userInfo);
            $('#dob').val(userInfo.dob).trigger('change');
            $('#gender').val(userInfo.gender ? userInfo.gender : '').trigger('change');
            $('#er_firstname').val(userInfo.er_firstname);
            $('#er_lastname').val(userInfo.er_lastname);
            $('#er_email').val(userInfo.er_email);
            $('#er_phone').val(userInfo.er_phone);
            $('#er_cnic').val(userInfo.er_cnic);
            $('#er_address').val(userInfo.er_address);
            
          }
        },
        error: function(xhr, status, error) {
          // Handle error response
          console.log('status');
        }
      });
    }

  $('form').each(function() {
    this.reset();
  });

  // $("#is_dependent").on('click', function() {
  //   if ($(this).is(':checked')) {
  //       $(this).val('1');
  //   } else {
  //       $(this).val('0');
  //   }
  // });
  // jQuery Validation
  // --------------------------------------------------------------------
  if (pageResetForm.length) {
    pageResetForm.validate({
      /*
      * ? To enable validation onkeyup
      onkeyup: function (element) {
        $(element).valid();
      },*/
      /*
      * ? To enable validation on focusout
      onfocusout: function (element) {
        $(element).valid();
      }, */
      rules: {
        'register-username': {
          required: false
        },
        'register-email': {
          required: false,
          email: true
        }
      }
    });
  }

  // multi-steps registration
  // --------------------------------------------------------------------

  // Horizontal Wizard
  if (typeof registerMultiStepsWizard !== undefined && registerMultiStepsWizard !== null) {
    var numberedStepper = new Stepper(registerMultiStepsWizard),
      $form = $(registerMultiStepsWizard).find('form');
    $form.each(function () {
      var $this = $(this);
      $this.validate({
        rules: {
          username: {
            required: false
          },
          email: {
            required: false
          },
          
          'first-name': {
            required: false
          },
          'home-address': {
            required: false
          },
          addCard: {
            required: false
          }
        },
        messages: {
          password: {
            required: 'Enter new password',
            minlength: 'Enter at least 8 characters'
          },
          'confirm-password': {
            required: 'Please confirm new password',
            minlength: 'Enter at least 8 characters',
            equalTo: 'The password and its confirm are not the same'
          }
        }
      });
    });

    $(registerMultiStepsWizard)
      .find('.btn-next')
      .each(function () {
        $(this).on('click', function (e) {
          var isValid = $(this).parent().siblings('form').valid();
          if (isValid) {
            numberedStepper.next();
          } else {
            e.preventDefault();
          }
        });
      });

    $(registerMultiStepsWizard)
      .find('.btn-prev')
      .on('click', function () {
        numberedStepper.previous();
      });

    $(registerMultiStepsWizard)
      .find('.btn-submit')
      .on('click', function () {
        var formData = {};
        var isValid = $(this).parent().siblings('form').valid();

        if (isValid) {          
          inputFields = $(registerMultiStepsWizard).find('form').find('input');
          inputFields.each(function() {
            var input = $(this);
            var fieldName = input.attr('name');
            var fieldValue = input.val();
            formData[fieldName] = fieldValue;
          });

          selectBoxes = $(registerMultiStepsWizard).find('form').find('select');
          selectBoxes.each(function() {
            var select = $(this);
            var fieldName = select.attr('name');
            var fieldValue = select.val();
            formData[fieldName] = fieldValue;
          });

          checkBox = $(registerMultiStepsWizard).find('form').find('checkbox');
          checkBox.each(function() {
            var select = $(this);
            var fieldName = select.attr('name');
            var fieldValue = select.val();
            formData[fieldName] = fieldValue;
          });

          formData['gender'] = $('input[name="gender"]:checked').val();
          if (formData) {

            if (formData['id']) {
              var dataSaveRoute = 'dependent/update';
              var successMesg = 'User updated successfully.';
            } else {
              var dataSaveRoute = 'dependent/create';
              var successMesg = 'User created successfully.';
            }
            $.ajax({
              url: assetPath + dataSaveRoute,
              type: 'POST',
              data:  formData,
              success: function(response) {
                if (response.status == 'success') {
                  Swal.fire({
                    title: 'Success',
                    text: successMesg,
                    icon: 'success',
                    confirmButtonText: 'OK'
                  });
                }
              },
              error: function(xhr, status, error) {
                Swal.fire({
                  title: 'error',
                  text: error,
                  icon: 'error',
                  confirmButtonText: 'OK'
                });
              }
            });
          }
        }
      });
  }

  // select2
  select.each(function () {
    var $this = $(this);
    $this.wrap('<div class="position-relative"></div>');
    $this.select2({
      // the following code is used to disable x-scrollbar when click in select input and
      // take 100% width in responsive also
      dropdownAutoWidth: true,
      width: '100%',
      dropdownParent: $this.parent()
    });
  });

  // credit card

  // Credit Card
  if (creditCard.length) {
    creditCard.each(function () {
      new Cleave($(this), {
        creditCard: true,
        onCreditCardTypeChanged: function (type) {
          const elementNodeList = document.querySelectorAll('.card-type');
          if (type != '' && type != 'unknown') {
            //! we accept this approach for multiple credit card masking
            for (let i = 0; i < elementNodeList.length; i++) {
              elementNodeList[i].innerHTML =
                '<img src="' + assetsPath + 'images/icons/payments/' + type + '-cc.png" height="24"/>';
            }
          } else {
            for (let i = 0; i < elementNodeList.length; i++) {
              elementNodeList[i].innerHTML = '';
            }
          }
        }
      });
    });
  }

  // Expiry Date Mask
  if (expiryDateMask.length) {
    new Cleave(expiryDateMask, {
      date: true,
      delimiter: '/',
      datePattern: ['m', 'y']
    });
  }

  // CVV
  if (cvvMask.length) {
    new Cleave(cvvMask, {
      numeral: true,
      numeralPositiveOnly: true
    });
  }

  // phone number mask
  if (mobileNumberMask.length) {
    new Cleave(mobileNumberMask, {
      phone: true,
      phoneRegionCode: 'US'
    });
  }

  // Pincode
  if (pinCodeMask.length) {
    new Cleave(pinCodeMask, {
      delimiter: '',
      numeral: true
    });
  }
  var assetPath = '../../../app-assets/',
  userView = 'app-user-view-account.html';

  if ($('body').attr('data-framework') === 'laravel') {
    assetPath = $('body').attr('data-asset-path');
    userView = assetPath + 'app/user/view/account';
  }

  
  function fetchRecord(url) {
    var deferred = $.Deferred();
    if (url) {
      $.ajax({
        url: url,
        type: 'GET', // or 'GET' depending on your needs
        data:  {},
        success: function(response) {
          // Handle success response
          if (response.length > 0) {
            deferred.resolve(response);
          }
        },
        error: function(xhr, status, error) {
          // Handle error response
          deferred.reject(error);
        }
      });
      return deferred.promise();
    }
  }
  
  //create html 
  function readyPatientsFields (PatientsInfo) {
    if (PatientsInfo) {
      $("#genaric_field1").show();
      $("#genaric_field1").empty();

      PatientsInfo = JSON.parse(PatientsInfo);
      var PatientTypeDropdown = $('<select class="select2 w-100" name="patient_type_id" id="patient_type_id"></select>');
      $.each(PatientsInfo, function(key, value) {
            // Add options to the select dropdown
        PatientTypeDropdown.append('<option value="'+ value['id'] +'">'+ value['name'] +'</option>');
      });
      
      $("#genaric_field1").append('<label class="form-label" for="patienttype">Patient Type</label>');
      $("#genaric_field1").append(PatientTypeDropdown);
      $('#patient_type_id').select2();
      return true;
    }
    return false;
  }

  function readyDoctorsFields (DoctorsInfo) {
    if (DoctorsInfo) {
      $("#genaric_field1").show();
      $("#genaric_field1").empty();
      DoctorsInfo = JSON.parse(DoctorsInfo);
      var doctorsTypeDropdown = $('<select class="select2 w-100" name="doctor_type_id" id="doctor_type_id"></select>');
      $.each(DoctorsInfo, function(key, value) {
            // Add options to the select dropdown
            doctorsTypeDropdown.append('<option value="'+ value['id'] +'">'+ value['name'] +'</option>');
      });
      
      $("#genaric_field1").append('<label class="form-label" for="doctortype">Doctors Type</label>');
      $("#genaric_field1").append(doctorsTypeDropdown);
      $('#doctor_type_id').select2();
      return true;
    }
    return false;
  }

  // multi-steps registration
  // --------------------------------------------------------------------
});
